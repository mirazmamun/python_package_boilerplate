Package Scaffolding
-------------------

To use import the package like the following:

    >>> import package