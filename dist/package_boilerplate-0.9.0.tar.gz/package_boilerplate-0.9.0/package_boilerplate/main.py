def main():
    return 'Welcome to the package setup tool. Something more'