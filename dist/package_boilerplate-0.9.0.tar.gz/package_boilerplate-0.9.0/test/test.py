from package_boilerplate import main
print(main())